const $=s=>document.querySelector(s);
const G={on:0,done:0,t:22,area:0,q:0,clues:[],rep:{police:0,street:0,press:0},fl:{},chase:null,nl:12,lf:0};
const has=c=>G.clues.includes(c);
const CN={watch:['ساعة 3:47','ساعة الدكتور متوقفة عند 3:47.'],ledger:['دفتر الخزنة','حسابات تهريب بتوقيع ليلى فارس.'],umbrella:['شهادة المظلة','امرأة بمظلة بيضاء غادرت مع الدكتور.'],manifest:['بيان الشحن','المخزن التاسع باسم «فارس القابضة».'],letter:['رسالة الساعاتي','«إن أصابني مكروه فالحقيقة في الخزنة… وليلى لا تعمل وحدها.»'],bribe:['ظرف المال','ظرف نقود ممهور بشعار «فارس القابضة» سلّمه لك كامل ليسكتك.'],records:['سجل الأرشيف','ليلى فارس وريثة «فارس القابضة» ومديرتها الفعلية.'],badge:['شارة مطرّزة','شارة بحرف F سقطت من الظلّ.']};
const RP={police:'الشرطة',street:'الشارع',press:'الصحافة'};
/* sound */
let AC,mute=0,amb,ambR,ENG,FX=1,AM=1,SENS=.006;
const ac=()=>{if(!AC)try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}return AC};
function tone(f,d=.15,t='sine',v=.06,at=0,sl=0){const a=ac();if(!a||mute)return;const o=a.createOscillator(),g=a.createGain(),n=a.currentTime+at;o.type=t;o.frequency.setValueAtTime(f,n);if(sl)o.frequency.exponentialRampToValueAtTime(sl,n+d);g.gain.setValueAtTime(v*FX,n);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g).connect(a.destination);o.start(n);o.stop(n+d)}
const sfx={click:()=>tone(520,.07,'triangle'),step:()=>tone(80+Math.random()*40,.06,'triangle',.035),clue:()=>{tone(660,.15);tone(990,.3,'sine',.06,.12)},bad:()=>tone(120,.4,'square',.05,0,55),door:()=>tone(240,.4,'triangle',.05,0,520),alarm:()=>[0,.25,.5].forEach(t=>tone(880,.2,'square',.04,t,660))};
function thunder(){const a=ac();if(!a||mute)return;const n=a.sampleRate*1.6|0,b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2);const s=a.createBufferSource(),f=a.createBiquadFilter(),g=a.createGain();f.type='lowpass';f.frequency.value=220;g.gain.value=.22;s.buffer=b;s.connect(f).connect(g).connect(a.destination);s.start()}
function startAmb(){const a=ac();if(!a||amb)return;const o=a.createOscillator(),g=a.createGain();o.type='sine';o.frequency.value=55;g.gain.value=.018;o.connect(g).connect(a.destination);o.start();amb=g;const n=a.sampleRate*2|0,b=a.createBuffer(1,n,a.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;const sr=a.createBufferSource(),f=a.createBiquadFilter(),rg=a.createGain();sr.buffer=b;sr.loop=true;f.type='bandpass';f.frequency.value=900;f.Q.value=.4;rg.gain.value=.008;sr.connect(f).connect(rg).connect(a.destination);sr.start();ambR=rg;const eo=a.createOscillator(),eg=a.createGain(),ef=a.createBiquadFilter();eo.type='sawtooth';eo.frequency.value=50;eg.gain.value=0;ef.type='lowpass';ef.frequency.value=320;eo.connect(ef).connect(eg).connect(a.destination);eo.start();ENG=[eo,eg]}
function toast(m){const t=document.createElement('div');t.className='t';t.textContent=m;$('#toasts').append(t);setTimeout(()=>t.remove(),2800)}
const btn=(l,f)=>{const b=document.createElement('button');b.className='b';b.textContent=l;b.onclick=()=>{sfx.click();f()};return b};
function addClue(c){if(has(c))return;G.clues.push(c);ach('first');if(G.clues.length>=8)ach('all');if(['umbrella','manifest','records'].includes(c)&&!G.fl.c3){G.fl.c3=1;setTimeout(()=>chapter('الفصل الثالث','خيوط تحت المطر'),1800)}sfx.clue();toast('دليل جديد: '+CN[c][0])}
function rep(k,n){G.rep[k]=Math.max(-5,Math.min(5,G.rep[k]+n));toast(RP[k]+(n>0?' ▲':' ▼'))}
const score=()=>G.clues.length;
/* rain overlay */
const rc=$('#rain'),rx=rc.getContext('2d');let dr=[];
function rrs(){rc.width=innerWidth;rc.height=innerHeight;dr=Array.from({length:Math.min(140,innerWidth/6|0)},()=>({x:Math.random()*rc.width,y:Math.random()*rc.height,l:8+Math.random()*14,v:9+Math.random()*8}))}
function rainF(){if(!matchMedia('(prefers-reduced-motion:reduce)').matches){rx.clearRect(0,0,rc.width,rc.height);rx.strokeStyle='rgba(150,190,200,.2)';rx.beginPath();for(const d of dr){rx.moveTo(d.x,d.y);rx.lineTo(d.x-2,d.y+d.l);d.y+=d.v;if(d.y>rc.height){d.y=-20;d.x=Math.random()*rc.width}}rx.stroke()}requestAnimationFrame(rainF)}
addEventListener('resize',rrs);rrs();rainF();
/* three setup */
const RD=new THREE.WebGLRenderer({antialias:true});RD.setPixelRatio(Math.min(devicePixelRatio,matchMedia('(pointer:coarse)').matches?1.5:2));RD.shadowMap.enabled=true;RD.shadowMap.type=THREE.PCFSoftShadowMap;RD.toneMapping=THREE.ACESFilmicToneMapping;RD.toneMappingExposure=1.15;$('#gl').append(RD.domElement);
const SC=new THREE.Scene();SC.fog=new THREE.Fog(0x05080d,22,120);
const CAM=new THREE.PerspectiveCamera(62,1,.1,300);
const HEM=new THREE.HemisphereLight(0x7fa0c8,0x0a0e13,.6),SUN=new THREE.DirectionalLight(0xbdd0ff,.8),LAMP=new THREE.PointLight(0xffb86b,1,18,2);
SUN.castShadow=true;SUN.shadow.mapSize.set(2048,2048);SUN.shadow.bias=-.0004;Object.assign(SUN.shadow.camera,{left:-35,right:35,top:35,bottom:-35,near:1,far:150});SUN.shadow.camera.updateProjectionMatrix();
SC.add(HEM,SUN,SUN.target,LAMP);
function rz(){RD.setSize(innerWidth,innerHeight);CAM.aspect=innerWidth/innerHeight;CAM.updateProjectionMatrix()}addEventListener('resize',rz);rz();
const M=(c,o)=>new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.85,metalness:.05},o));
const city=new THREE.Group();SC.add(city);
let sd=7;const rnd=()=>(sd=sd*16807%2147483647)/2147483647;
function bx(w,h,d,m,x,y,z,p){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;(p||city).add(o);return o}
const BX=[],EM=[],BL=[];
const col=(x,z,w,d)=>BX.push({x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2});
const gd=new THREE.Mesh(new THREE.PlaneGeometry(400,400),M(0x10151b,{roughness:.35,metalness:.2}));gd.rotation.x=-Math.PI/2;gd.receiveShadow=true;city.add(gd);
{const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.fillStyle='#10151b';g.fillRect(0,0,128,128);for(let i=0;i<900;i++){g.fillStyle='rgba('+(20+Math.random()*30|0)+','+(25+Math.random()*30|0)+','+(32+Math.random()*30|0)+',.5)';g.fillRect(Math.random()*128,Math.random()*128,1+Math.random()*2,1+Math.random()*2)}const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(120,120);gd.material.map=t;gd.material.color.setHex(0xffffff);gd.material.needsUpdate=true}
const pc2=document.createElement('canvas');pc2.width=pc2.height=64;{const g=pc2.getContext('2d');g.fillStyle='#2a3540';g.fillRect(0,0,64,64);g.strokeStyle='#161c23';g.lineWidth=3;g.strokeRect(0,0,64,64)}const PT=new THREE.CanvasTexture(pc2);PT.wrapS=PT.wrapT=THREE.RepeatWrapping;PT.repeat.set(11,11);const SLM=M(0xffffff,{map:PT,roughness:.6});
const wt=new THREE.Mesh(new THREE.PlaneGeometry(100,400),M(0x07121c,{roughness:.2,metalness:.5}));wt.rotation.x=-Math.PI/2;wt.position.set(142,.02,0);city.add(wt);
const wc=document.createElement('canvas');wc.width=wc.height=64;{const g=wc.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,64,64);for(let y=0;y<4;y++)for(let x=0;x<4;x++)if(rnd()<.45){g.fillStyle=rnd()<.5?'#ffcf80':'#c98d45';g.fillRect(x*16+4,y*16+4,8,9)}}
const WT=new THREE.CanvasTexture(wc);WT.wrapS=WT.wrapT=THREE.RepeatWrapping;
const ST=[-48,-16,16,48],LM={tower:[2,0],bar:[1,2],docks:[4,4],villa:[0,4],plaza:[2,2],archive:[0,1]};
function bld(cx,cz,w,d,h,dc){const t=WT.clone();t.needsUpdate=true;t.repeat.set(w/8,h/8);t.offset.set(rnd(),rnd());const m=M([0x1c242e,0x2a1d1b,0x262a24,0x2c2a35,0x30261c][Math.random()*5|0],{emissive:0xffb050,emissiveMap:t});EM.push(m);bx(w,h,d,m,cx,h/2,cz);col(cx,cz,w,d);bx(w*.3,1.4,d*.25,M(0x151a20),cx+w*.15,h+.7,cz-d*.1);BL.push([cx,cz,w,d,h,dc]);{const st=M(0x2e3640),pm=M(0x1a1f26);bx(w+.5,1.4,d+.5,M(0x14161a),cx,.7,cz);bx(w+.8,.5,d+.8,st,cx,h+.25,cz);if(h>14){bx(w+.4,.35,d+.4,st,cx,h*.5,cz);bx(w+.4,.35,d+.4,st,cx,h*.25,cz)}
 for(const k of[-.3,.3])for(const sg of[-1,1])bx(.5,h,.5,pm,cx+w*k,h/2,cz+sg*(d/2+.12));
 if(h>22){bx(w*.7,6,d*.7,M(0x1c242e),cx,h+3.25,cz);bx(w*.7+.6,.4,d*.7+.6,st,cx,h+6.45,cz)}
 if(!dc&&w==16){const sf=new THREE.Mesh(new THREE.PlaneGeometry(w*.7,2.4),new THREE.MeshBasicMaterial({color:0x6a4a22}));sf.position.set(cx,1.9,cz+d/2+.27);city.add(sf)}}if(Math.random()<.6)bx(.12,4,.12,M(0x0b0b0b),cx-w*.25,h+2,cz+d*.2);if(Math.random()<.5){const tk=new THREE.Mesh(new THREE.CylinderGeometry(1,1,1.8,10),M(0x2a2018));tk.position.set(cx-w*.2,h+.9,cz-d*.25);tk.castShadow=true;city.add(tk)}if(dc)bx(3.8,.15,1.7,M([0x7a2a2e,0x2a4a5a,0x4a3a1e][Math.random()*3|0]),cx,3.9,cz+d/2+.8);
 if(dc){const dr=new THREE.Mesh(new THREE.PlaneGeometry(2.4,3.4),new THREE.MeshBasicMaterial({color:0xffb86b}));dr.position.set(cx,1.7,cz+d/2+.05);city.add(dr)}}
for(let i=0;i<5;i++)for(let j=0;j<5;j++){const cx=(i-2)*32,cz=(j-2)*32,k=Object.keys(LM).find(n=>LM[n][0]==i&&LM[n][1]==j);
 bx(22,.12,22,SLM,cx,.06,cz);
 if(k=='plaza'){{const st=M(0x3a444e),b=new THREE.Mesh(new THREE.CylinderGeometry(3,3.2,.7,24),st);b.position.y=.35;b.castShadow=b.receiveShadow=true;city.add(b);const w=new THREE.Mesh(new THREE.CylinderGeometry(2.7,2.7,.05,24),new THREE.MeshBasicMaterial({color:0x1a3a52}));w.position.y=.66;city.add(w);bx(.6,2.2,.6,st,0,1.4,0);const bw=new THREE.Mesh(new THREE.CylinderGeometry(1.1,.5,.4,16),st);bw.position.y=2.6;city.add(bw);col(0,0,6.4,6.4);bx(1.2,.5,3,st,6.5,.35,0);bx(1.2,.5,3,st,-6.5,.35,0);col(6.5,0,1.2,3);col(-6.5,0,1.2,3)}}
 else if(k=='tower')bld(cx,cz,12,12,34,1);
 else if(k=='bar'){bld(cx,cz,16,16,10,1);sign(cx,cz)}
 else if(k=='archive')bld(cx,cz,16,16,12,1);
 else if(k=='villa')bld(cx,cz-4,22,14,13,0);
 else if(k=='docks'){for(let n=0;n<7;n++){const x=cx+(rnd()-.5)*16,z=cz+(rnd()-.5)*16;if(Math.hypot(x-70,z-70)<4||Math.hypot(x-58,z-58)<4)continue;bx(3,3,3,M(0x3b2f22),x,1.5,z);col(x,z,3,3)}
  bx(3,3,3,M(0x5a4220,{emissive:0x553311}),70,1.5,70);col(70,70,3,3);bx(2,34,2,M(0x2a1f18),84,17,40);bx(2,2,26,M(0x2a1f18),84,34,28)}
 else bld(cx,cz,16,16,10+rnd()*22,0)}
const blk=M(0x0b0b0b);
function hand(len,a){const g=new THREE.Group();bx(.3,len,.1,blk,0,len/2,0,g);g.rotation.z=-a*Math.PI/180;g.position.set(0,28,-57.9);city.add(g)}
{const f=new THREE.Mesh(new THREE.CircleGeometry(4,24),new THREE.MeshBasicMaterial({color:0xffe2a8}));f.position.set(0,28,-57.95);city.add(f);hand(2.2,113);hand(3.3,282)}
const gc=document.createElement('canvas');gc.width=gc.height=64;{const g=gc.getContext('2d'),r=g.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba(255,190,110,.9)');r.addColorStop(1,'rgba(255,170,80,0)');g.fillStyle=r;g.fillRect(0,0,64,64)}
const GM=new THREE.SpriteMaterial({map:new THREE.CanvasTexture(gc),blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,fog:false,opacity:.8});
const LP=new THREE.MeshBasicMaterial({map:GM.map,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,opacity:.4});
for(const a of ST)for(const b of ST){bx(.2,5,.2,M(0x1a1f25),a+5.5,2.5,b+5.5);const bl=new THREE.Mesh(new THREE.SphereGeometry(.3,8,6),new THREE.MeshBasicMaterial({color:0xffd08a}));bl.position.set(a+5.5,5.1,b+5.5);city.add(bl);const sp=new THREE.Sprite(GM);sp.scale.set(7,7,1);sp.position.copy(bl.position);city.add(sp);const pq=new THREE.Mesh(new THREE.PlaneGeometry(10,10),LP);pq.rotation.x=-Math.PI/2;pq.position.set(a+4,.08,b+4);city.add(pq)}
function sign(x,z,t='حانة الفانوس',cl='#ff9a3c',dz=8.45,y=5.8){const c=document.createElement('canvas');c.width=256;c.height=64;const g=c.getContext('2d');g.font='bold 40px Tajawal,sans-serif';g.textAlign='center';g.fillStyle=cl;g.shadowColor=cl;g.shadowBlur=14;g.fillText(t,128,46);const m=new THREE.Mesh(new THREE.PlaneGeometry(7,1.75),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(c),transparent:true,fog:false}));m.position.set(x,y,z+dz);city.add(m)}
{const dm=new THREE.InstancedMesh(new THREE.PlaneGeometry(.35,3).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x6b6a5a}),700),mt=new THREE.Matrix4(),qa=new THREE.Quaternion(),qb=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),Math.PI/2),one=new THREE.Vector3(1,1,1);let n=0;
 for(const a of ST)for(let t=-90;t<=90;t+=8){if(ST.some(v=>Math.abs(t-v)<7))continue;dm.setMatrixAt(n++,mt.compose(new THREE.Vector3(a,.07,t),qa,one));dm.setMatrixAt(n++,mt.compose(new THREE.Vector3(t,.07,a),qb,one))}
 dm.count=n;city.add(dm)}
for(const[x,z]of[[-8,-8],[8,-8],[-8,8],[8,8],[0,-9],[0,9],[-9,0],[9,0]]){bx(.4,2.2,.4,M(0x2a1d14),x,1.1,z);const cn=new THREE.Mesh(new THREE.ConeGeometry(2.2,4.5,8),M(0x14261c));cn.position.set(x,4.4,z);cn.castShadow=true;city.add(cn);col(x,z,.7,.7)}
{const W=[['صيدلية','#5fd6a0'],['فندق الليل','#c88bff'],['مقهى الحي','#ffcf5a'],['ساعات','#7fb3bd'],['كازينو','#ff5a7a'],['مخبز','#ffb46a'],['سينما','#6ac1ff'],['عيادة','#a6ffdf']];BL.filter(b=>!b[5]&&b[2]==16).slice(0,8).forEach((b,i)=>sign(b[0],b[1],W[i][0],W[i][1],b[3]/2+.45,4.5+Math.random()*2));sign(-64,-32,'أرشيف المدينة','#9ad0ff',8.45,5.2)}
for(const[x,z,cc]of[[-43.9,-32,0x3a1c1c],[-20.1,32,0x1c2b3a],[20.1,0,0x2a2a2a],[43.9,-32,0x3a331c],[-52.1,0,0x233a2a],[11.9,-32,0x3a1c2a]]){const g=car(cc);g.position.set(x,0,z);g.rotation.y=Math.PI/2;city.add(g);col(x,z,2,4.4)}
const SV2=[];for(const[x,z]of[[-32,-48],[32,16],[-16,32],[48,-16],[0,48],[-48,16]])for(let i=0;i<3;i++){const sq=new THREE.Sprite(new THREE.SpriteMaterial({map:GM.map,color:0xaab6c2,transparent:true,depthWrite:false,opacity:0}));city.add(sq);SV2.push({sq,x,z,o:i/3});if(!i)bx(.9,.05,.9,M(0x0a0c0f),x,.06,z)}
for(const a of ST)for(const b of ST){bx(.15,4.2,.15,M(0x15191e),a-5.5,2.1,b+5.5);const tl=new THREE.Mesh(new THREE.BoxGeometry(.35,1,.35),new THREE.MeshBasicMaterial({color:Math.random()<.5?0xff3b2f:0x3bff6a}));tl.position.set(a-5.5,4.4,b+5.5);city.add(tl);
 const hy=new THREE.Mesh(new THREE.CylinderGeometry(.2,.22,.7,8),M(0x8a1f1f));hy.position.set(a-5.6,.35,b-5.6);hy.castShadow=true;city.add(hy);col(a-5.6,b-5.6,.5,.5);
 const bn=new THREE.Mesh(new THREE.CylinderGeometry(.4,.36,.9,10),M(0x1d2a22));bn.position.set(a+5.6,.45,b-5.6);bn.castShadow=true;city.add(bn);col(a+5.6,b-5.6,.8,.8)}
{const zm=new THREE.InstancedMesh(new THREE.PlaneGeometry(.6,3.2).rotateX(-Math.PI/2),new THREE.MeshBasicMaterial({color:0x8a8878}),600),mt=new THREE.Matrix4(),q0=new THREE.Quaternion(),q1=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),Math.PI/2),one=new THREE.Vector3(1,1,1);let n=0;
 for(const a of ST)for(const b of ST)for(let k=-4;k<=4;k++){const o=k*.9;zm.setMatrixAt(n++,mt.compose(new THREE.Vector3(a+o,.08,b-7.5),q0,one));zm.setMatrixAt(n++,mt.compose(new THREE.Vector3(a+o,.08,b+7.5),q0,one));zm.setMatrixAt(n++,mt.compose(new THREE.Vector3(a-7.5,.08,b+o),q1,one));zm.setMatrixAt(n++,mt.compose(new THREE.Vector3(a+7.5,.08,b+o),q1,one))}zm.count=n;city.add(zm)}
for(let i=0;i<40;i++){const t2=WT.clone();t2.needsUpdate=true;const w=10+Math.random()*14,h=35+Math.random()*60;t2.repeat.set(w/8,h/8);t2.offset.set(Math.random(),Math.random());const m=M(0x151a22,{emissive:0xffb050,emissiveMap:t2});EM.push(m);const ang=i/40*6.283,r=108+Math.random()*10;bx(w,h,w,m,Math.cos(ang)*r,h/2,Math.sin(ang)*r)}
function car(cb,o={}){const g=new THREE.Group(),B=M(cb,{metalness:.5,roughness:.35}),GL=M(0x0b1620,{metalness:.9,roughness:.08}),DK=M(0x101010),U=g.userData;U.wh=[];U.fw=[];
 bx(4.3,.5,1.85,B,0,.55,0,g);bx(1.5,.1,1.78,B,1.35,.85,0,g);bx(1.1,.1,1.78,B,-1.55,.85,0,g);bx(2.1,.6,1.62,GL,-.1,1.13,0,g);bx(1.75,.08,1.66,B,-.1,1.47,0,g);
 for(const x of[-1.1,.9])for(const z of[-.8,.8])bx(.1,.62,.08,B,x,1.13,z,g);
 bx(.2,.25,1.92,DK,2.2,.45,0,g);bx(.2,.25,1.92,DK,-2.2,.45,0,g);bx(.05,.18,.9,DK,2.18,.65,0,g);bx(.12,.1,.2,B,.75,1.0,1.0,g);bx(.12,.1,.2,B,.75,1.0,-1.0,g);bx(.03,.14,.4,M(0xe8e0c8),-2.19,.55,0,g);
 if(o.s){const S=M(0xe8dcc0);bx(1.5,.02,.3,S,1.35,.91,0,g);bx(1.1,.02,.3,S,-1.55,.91,0,g);bx(1.75,.02,.3,S,-.1,1.52,0,g)}
 U.tl=new THREE.MeshBasicMaterial({color:0x771111});
 for(const z of[-.7,.7]){const h=new THREE.Mesh(new THREE.BoxGeometry(.06,.14,.4),new THREE.MeshBasicMaterial({color:0xfff2c4}));h.position.set(2.17,.75,z);g.add(h);const t=new THREE.Mesh(new THREE.BoxGeometry(.06,.14,.4),U.tl);t.position.set(-2.17,.75,z);g.add(t)}
 for(const x of[-1.4,1.4])for(const z of[-.95,.95]){const pv=new THREE.Group();pv.position.set(x,.38,z);g.add(pv);const sp=new THREE.Group();pv.add(sp);const t=new THREE.Mesh(new THREE.CylinderGeometry(.38,.38,.28,16),DK);t.rotation.x=Math.PI/2;sp.add(t);const r=new THREE.Mesh(new THREE.CylinderGeometry(.24,.24,.3,12),M(0x9aa3ab,{metalness:.8,roughness:.3}));r.rotation.x=Math.PI/2;sp.add(r);sp.add(new THREE.Mesh(new THREE.BoxGeometry(.5,.05,.31),DK));U.wh.push(sp);if(x>0)U.fw.push(pv)}
 const hs=new THREE.Sprite(GM);hs.scale.set(6,6,1);hs.position.set(2.8,.9,0);g.add(hs);if(o.l){const hl=new THREE.PointLight(0xfff0c0,1.3,24,2);hl.position.set(4,1.3,0);g.add(hl)}
 g.traverse(m=>m.castShadow=true);return g}
const PC=car(0x7a1f26,{s:1,l:1});PC.position.set(-8,0,19);city.add(PC);
const CR=[];for(let i=0;i<4;i++){const g=car([0x3a1c1c,0x1c2b3a,0x2a2a2a,0x3a331c][i]);city.add(g);const s=i<2?1:-1;CR.push({g,ax:i%2,s,l:ST[(i*3+1)%4]+(s>0?2.2:-2.2),p:-80+i*40,v:7+i})}
{const c=document.createElement('canvas');c.width=512;c.height=300;const g=c.getContext('2d');g.fillStyle='#2a1c10';g.fillRect(0,0,512,300);
 for(let r=0;r<3;r++)for(let k=0;k<7;k++){if(r==2&&k==3)continue;const x=20+k*70,y=22+r*88,gr=g.createLinearGradient(0,y,0,y+62);gr.addColorStop(0,'#ffe3a6');gr.addColorStop(1,'#ffb55a');g.fillStyle=gr;g.fillRect(x,y,50,62);g.fillStyle='#3a2410';g.fillRect(x+23,y,4,62);g.fillRect(x,y+29,50,4)}
 g.fillStyle='#ffd48a';g.fillRect(228,206,56,94);g.fillStyle='#3a2410';g.fillRect(254,206,4,94);
 const f=new THREE.Mesh(new THREE.PlaneGeometry(22,13),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(c)}));f.position.set(-64,6.5,67.06);city.add(f);
 const VM=new THREE.SpriteMaterial({map:GM.map,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,fog:false,opacity:.9});
 const gl=new THREE.Sprite(VM);gl.scale.set(34,22,1);gl.position.set(-64,6.5,69);city.add(gl);
 const pool=new THREE.Mesh(new THREE.PlaneGeometry(34,26),new THREE.MeshBasicMaterial({map:GM.map,transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,opacity:.55}));pool.rotation.x=-Math.PI/2;pool.position.set(-64,.09,75);city.add(pool);
 for(const x of[-76,-52]){bx(.2,4,.2,M(0x1a1f25),x,2,73);const b=new THREE.Mesh(new THREE.SphereGeometry(.35,8,6),new THREE.MeshBasicMaterial({color:0xffd9a0}));b.position.set(x,4.1,73);city.add(b);const sp=new THREE.Sprite(VM);sp.scale.set(9,9,1);sp.position.copy(b.position);city.add(sp)}
 for(const [y,z,i] of [[6,74,2.4],[3,70,1.4]]){const l=new THREE.PointLight(0xffb86b,i,34,2);l.position.set(-64,y,z);city.add(l)}}
/* characters */
function ch(c,hat,sf){const g=new THREE.Group(),U=g.userData,pu=[],sk=[0xd9b99b,0xc99a76,0x9a6b4a,0xe4c4a8][(c>>3)%4],pc=0x1b1e24,hc=0x1b1410,
 mk=(geo,col,p,x,y,z,sx=1,sy=1,sz=1,bs)=>{const o=new THREE.Mesh(geo,bs?new THREE.MeshBasicMaterial({color:col}):M(col));o.position.set(x,y,z);o.scale.set(sx,sy,sz);p.add(o);return o},
 cyl=(a,b,h)=>new THREE.CylinderGeometry(a,b,h,12),sp=new THREE.SphereGeometry(1,12,10),
 gp=(p,x,y)=>{const o=new THREE.Group();o.position.set(x,y,0);p.add(o);return o};
 const leg=x=>{const p=gp(g,x,.92),k=gp(p,0,-.46);mk(cyl(.085,.065,.46),pc,p,0,-.23,0);mk(sp,pc,k,0,0,0,.065,.065,.065);mk(cyl(.065,.05,.44),pc,k,0,-.22,0);mk(sp,0x0d0d0d,k,0,-.47,.05,.055,.04,.11);return[p,k]};
 const[l1,k1]=leg(-.1),[l2,k2]=leg(.1);
 U.bd=mk(cyl(.2,.17,.56),c,g,0,1.22,0);mk(cyl(.235,.3,.5),c,g,0,.8,0);mk(cyl(.2,.2,.04),0x0e0e0e,g,0,1.0,0);
 mk(new THREE.BoxGeometry(.1,.22,.02),0xe8e4da,g,0,1.36,.2);mk(new THREE.BoxGeometry(.03,.2,.02),0x7a2a2e,g,0,1.34,.212);
 const arm=x=>{const p=gp(g,x,1.44),e=gp(p,0,-.3);mk(sp,c,p,0,0,0,.075,.075,.075);mk(cyl(.055,.045,.3),c,p,0,-.15,0);mk(cyl(.045,.038,.27),c,e,0,-.135,0);mk(sp,sk,e,0,-.3,0,.045,.05,.045);return[p,e]};
 const[a1,e1]=arm(-.25),[a2,e2]=arm(.25);
 mk(cyl(.045,.05,.12),sk,g,0,1.6,0);if(sf)mk(new THREE.TorusGeometry(.075,.03,8,14),sf,g,0,1.56,0).rotation.x=Math.PI/2;
 const h=gp(g,0,1.72);mk(sp,sk,h,0,0,0,.095,.12,.105);mk(sp,sk,h,0,-.015,.105,.02,.026,.03);
 for(const x of[-1,1]){mk(sp,sk,h,x*.095,0,0,.015,.028,.02);mk(sp,hat==2?0xff5a3c:0xf2efe6,h,x*.038,.02,.09,.017,.012,.012,1);
  if(hat!=2){pu.push(mk(sp,0x1a1008,h,x*.038,.02,.099,.009,.009,.006,1));mk(new THREE.BoxGeometry(.05,.009,.012),hc,h,x*.04,.048,.092,1,1,1,1).rotation.z=-x*.15}}
 if(hat!=2)mk(new THREE.BoxGeometry(.04,.006,.008),0x5a2e2a,h,0,-.05,.098,1,1,1,1);
 mk(sp,hc,h,0,-.01,-.03,.098,.115,.09);
 if(hat==1){mk(cyl(.2,.2,.012),0x15130f,h,0,.09,0);mk(cyl(.105,.115,.1),0x15130f,h,0,.14,0);mk(cyl(.109,.109,.02),0x6a1f1f,h,0,.1,0)}
 else if(hat==2)mk(new THREE.SphereGeometry(1,12,8,0,6.283,0,1.3),0x050505,h,0,.01,-.03,.115,.15,.125);
 else mk(new THREE.SphereGeometry(1,12,8,0,6.283,0,1.15),hc,h,0,.012,-.012,.1,.125,.11);
 {const dk=new THREE.Color(c).multiplyScalar(.65).getHex();for(const x of[-1,1])mk(new THREE.BoxGeometry(.1,.4,.03),dk,g,x*.075,1.37,.195).rotation.z=-x*.22;for(const y of[1.28,1.15])mk(sp,0x0b0b0b,g,0,y,.205,.014,.014,.01,1);mk(new THREE.BoxGeometry(.06,.05,.02),0xb89a4a,g,0,1.0,.205,1,1,1,1)}
 Object.assign(U,{l1,l2,k1,k2,a1,a2,e1,e2,pu});g.traverse(o=>o.castShadow=true);return g}
const anim=(g,t,a=.7)=>{const u=g.userData,z=Math.sin(t);u.l1.rotation.x=z*a;u.l2.rotation.x=-z*a;u.k1.rotation.x=Math.max(0,Math.sin(t+1.3))*a*1.2;u.k2.rotation.x=Math.max(0,-Math.sin(t+1.3))*a*1.2;u.a1.rotation.x=-z*a*.8;u.a2.rotation.x=z*a*.8;u.e1.rotation.x=-.2-Math.max(0,-z)*a*.5;u.e2.rotation.x=-.2-Math.max(0,z)*a*.5};
const pl=ch(0x5a4b3a,1,0xb8484b);pl.position.set(0,0,12);SC.add(pl);
const stg=new THREE.BufferGeometry(),spp=[];for(let i=0;i<350;i++){const a=Math.random()*6.283,e=Math.random()*1.3+.15,r=250;spp.push(Math.cos(a)*Math.cos(e)*r,Math.sin(e)*r,Math.sin(a)*Math.cos(e)*r)}stg.setAttribute('position',new THREE.Float32BufferAttribute(spp,3));
const STM=new THREE.PointsMaterial({color:0xdde8ff,size:1.6,sizeAttenuation:false,fog:false,transparent:true,depthWrite:false}),STR=new THREE.Points(stg,STM);STR.frustumCulled=false;SC.add(STR);
const MN=new THREE.Sprite(new THREE.SpriteMaterial({map:GM.map,color:0xcfe0ff,fog:false,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}));MN.scale.set(60,60,1);SC.add(MN);
/* interiors */
const O={1:[300,300],2:[-300,300],3:[0,-300]},INT={};
const RM=new THREE.SpriteMaterial({map:GM.map,blending:THREE.AdditiveBlending,depthWrite:false,transparent:true,fog:false,opacity:.8});
function room(a,c){const[ox,oz]=O[a],g=new THREE.Group();g.position.set(ox,0,oz);const r=new THREE.Mesh(new THREE.BoxGeometry(14,5,14),M(c,{side:THREE.BackSide,emissive:c,emissiveIntensity:.4}));r.position.y=2.5;r.receiveShadow=true;g.add(r);
 const f=new THREE.Mesh(new THREE.PlaneGeometry(14,14),M(0x3a2c20,{emissive:0x3a2c20,emissiveIntensity:.35}));f.rotation.x=-Math.PI/2;f.position.y=.01;g.add(f);
 for(const [x,y,z,i] of [[0,4,0,2.4],[-4.5,3,-4,1.3],[4.5,3,-4,1.3],[0,3,5,1]]){const l=new THREE.PointLight(0xffb86b,i,30,2);l.position.set(x,y,z);g.add(l)}
 const lb=new THREE.Mesh(new THREE.SphereGeometry(.3,8,6),new THREE.MeshBasicMaterial({color:0xffe2a8}));lb.position.set(0,4.5,0);g.add(lb);
 for(const [x,y,z,w] of [[0,4.4,0,7],[-6.5,3,-6.5,5],[6.5,3,-6.5,5],[-6.5,3,6.5,5],[6.5,3,6.5,5]]){const sp=new THREE.Sprite(RM);sp.scale.set(w,w,1);sp.position.set(x,y,z);g.add(sp)}
 const d=new THREE.Mesh(new THREE.PlaneGeometry(2.4,3.4),new THREE.MeshBasicMaterial({color:0xffb86b}));d.position.set(0,1.7,6.95);d.rotation.y=Math.PI;g.add(d);g.visible=false;SC.add(g);INT[a]=g;return g}
const g1=room(1,0x2a2622),g2=room(2,0x30211a),g3=room(3,0x25292e);
for(let i=-2;i<=2;i++)bx(2,3.4,.8,M(0x3a2d22),i*2.6,1.7,-6.4,g3);bx(5,.9,1.4,M(0x3a2a1c),0,.45,-2,g3);
bx(2,.5,.8,M(0x2a2024),-3,.3,-2,g1);bx(1.4,1.2,1,M(0x40464d,{metalness:.6}),4.5,.6,-5.5,g1);bx(3,.9,1.2,M(0x3a2a1c),-4,.45,-5.5,g1);
const gear=new THREE.Mesh(new THREE.TorusGeometry(1.6,.25,8,16),M(0x8a6a2a,{metalness:.7}));gear.position.set(0,2.8,-6.7);g1.add(gear);
bx(8,1.1,1.2,M(0x4a3020),0,.55,-3,g2);for(let i=0;i<5;i++){const b=new THREE.Mesh(new THREE.CylinderGeometry(.12,.12,.5,8),new THREE.MeshBasicMaterial({color:0xd89a3a}));b.position.set(-3+i*1.5,1.35,-3);g2.add(b)}
bx(2,.8,2,M(0x3a2a1c),-4,.4,3,g2);bx(2,.8,2,M(0x3a2a1c),4,.4,3,g2);
/* NPCs */
const NP=[];
function npc(n,c,hat,x,z,a,lines,sf){const g=ch(c,hat,sf);g.position.set(x,0,z);(a?INT[a]:city).add(g);if(a){g.position.set(x-O[a][0],0,z-O[a][1])}const o={g,n,x,z,a,lines};NP.push(o);return o}
const kamel=npc('المفتش كامل',0x3a4a5c,1,5,-54,0),nour=npc('نور',0x6a2c34,0,O[2][0],O[2][1]-4.2,2),zahir=npc('أبو زاهر',0x3b3326,1,58,58,0),layla=npc('ليلى فارس',0xe8e4dc,0,-64,72,0,0,0xb8484b),idris=npc('إدريس',0x4a4a3a,0,O[3][0]+3,O[3][1]-3,3);
const LN=["«سمعت أن الساعاتي كان يخشى شيئًا عند الفجر.»", "«الحانة في الغرب، والرصيف في الشرق. لا تذهب بلا حذر.»", "«أبو زاهر يحمي رجاله فقط.»", "«المظلة البيضاء… لا تُنسى في هذا المطر.»", "«لا تثق بأحد في هذا الحي.»", "«الساعة توقفت مرة واحدة فقط في عشرين سنة. الليلة.»", "«رأيت ظلًّا يركض قرب البرج قبل منتصف الليل.»", "«الشرطة وصلت متأخرة، كأنها كانت تنتظر.»", "«فارس القابضة تشتري نصف هذه المدينة.»", "«المطر لا يغسل شيئًا هنا، يكشف فقط.»", "«لا تسهر طويلًا، الفجر هنا لا يرحم أحدًا.»", "«سمير كان رجلًا طيبًا، وهذا ما قتله.»", "«قيل إن في الفيلا ضوءًا لا ينطفئ أبدًا.»", "«ابتعد عن الأزقة بعد منتصف الليل.»", "«هل أنت المحقق؟ سمعت أنك لا تُشترى.»", "«الأرشيف يحفظ أسرارًا أكثر مما يحفظ أوراقًا.»", "«إن كنت تبحث عن الحقيقة فاسأل نور، فهي تعرف كل شيء.»", "«سيارة سوداء مرّت من هنا مسرعة.»", "«الجو بارد… كأن المدينة تحبس أنفاسها.»", "«قبل أن تتهم أحدًا، اجمع ما يكفي.»"],BK={"المفتش كامل": ["«هل وجدت شيئًا؟ لا تتأخر، الفجر قريب.»", "«لا تلمس شيئًا في مسرح الجريمة بلا إذني.»", "«أعرف هذه المدينة أكثر منك يا تحرّي.»", "«القضية أبسط مما تظن… أو هكذا أريدها.»", "«بعض الأبواب الأفضل ألّا تُفتح.»"], "نور": ["«قلت لك كل ما أعرف.»", "«اشرب شيئًا أو غادر.»", "«الجميع هنا يكذب، لكن بالمجان.»", "«المظلة البيضاء… لا أنسى وجوه الزبائن.»", "«الليل أطول مما تتخيل يا سيدي.»"], "أبو زاهر": ["«الصناديق لك. لكن لا تنسَ وعدك.»", "«في ميناء أبي زاهر، لا شيء يضيع.»", "«عمّالي لا يرون ولا يسمعون.»", "«لا تظن أنني نسيت من فتّش صناديقي.»", "«الرصيف التاسع… لا يُسأل عنه.»"], "ليلى فارس": ["«تحرٍّ في بيتي؟ ما الذي تظن أنك تملك؟»", "«عد حين تملك شيئًا.»", "«الحقيقة سلعة غالية يا حضرة المحقق.»", "«لا أحب الضيوف الذين لا أدعوهم.»", "«سمير كان صديقًا قديمًا… مؤسف ما جرى.»"], "إدريس": ["«قرأت ما تحتاجه. لا تُخرج السجلات من هنا.»", "«الأوراق تتذكر ما ينساه الناس.»", "«اخفض صوتك، فللجدران آذان.»", "«كل ملف هنا يخفي حكاية.»", "«الوقت يمرّ، والغبار يتراكم على الحقيقة.»"]},pick=a=>a[Math.random()*a.length|0];
for(let i=0;i<8;i++){const o=npc('عابر',[0x4a3a3a,0x35453a,0x3a3a4f,0x50443a][i%4],i%2,0,0,0,LN);o.t=1;o.ix=i%4;o.iz=(i*3)%4;o.off=(i%2?3.5:-3.5);o.x=ST[o.ix]+o.off;o.z=ST[o.iz]+o.off;o.tx=o.x;o.tz=o.z;o.g.position.set(o.x,0,o.z)}
/* runner chase */
function startChase(){chapter('الفصل الثاني','ظلّ في المطر');const g=ch(0x08080a,2);g.position.set(0,0,-55);city.add(g);G.chase={g,i:0,time:40,spd:6.6,wp:[[0,-48],[16,-48],[16,16],[48,16],[48,48],[64,48]]};sfx.alarm();toast('ظلّ يفرّ من البرج! طارده!');G.lf=1}
function chaseUpd(dt){const c=G.chase;if(!c||c.done)return;c.time-=dt;const r=c.g,w=c.wp[c.i];if(w){const dx=w[0]-r.position.x,dz=w[1]-r.position.z,d=Math.hypot(dx,dz);if(d<.5)c.i++;else{r.position.x+=dx/d*c.spd*dt;r.position.z+=dz/d*c.spd*dt;r.rotation.y=Math.atan2(dx,dz);anim(r,G.t*900)}}
 if(!G.area&&Math.hypot(r.position.x-pl.position.x,r.position.z-pl.position.z)<2){c.done=1;city.remove(r);addClue('badge');ach('chase');say('الظلّ',['أمسكتَ به! يفلت منك لكنه يترك شارة مطرّزة بحرف F.'])}
 else if(c.time<=0||c.i>=c.wp.length){c.done=1;city.remove(r);toast('هرب الظلّ في الظلام…')}}
/* voice */
let VO=1;const VP={'المفتش كامل':[.8,.95],'نور':[1.3,1],'أبو زاهر':[.65,.9],'ليلى فارس':[1.2,.95],'إدريس':[.85,.85],'عابر':[1,1],'أنت':[.95,1],'حارس':[.75,1],'الظلّ':[.6,1]};
let VA=0,VT=null;
function blip(n,t){const p=(VP[n]||[1,1])[0],q=String(t).replace(/[^\u0600-\u06FF]/g,'').slice(0,90);let at=0;for(let i=0;i<q.length;i+=2){const c=q.charCodeAt(i);tone(150*p*(.8+(c%9)/18),.07,'triangle',.05,at);at+=.085}}
function speak(n,t){if(!VO)return;clearTimeout(VT);const ss=window.speechSynthesis;if(!ss||!window.SpeechSynthesisUtterance)return blip(n,t);
 try{const vs=ss.getVoices(),v=vs.find(v=>/^ar/i.test(v.lang));
  if(!VA&&vs.length){VA=1;toast(v?'صوت النطق: '+v.name:'لا يوجد صوت عربي في جهازك، سيُستخدم صوت تمثيلي بدلًا منه')}
  if(vs.length&&!v)return blip(n,t);
  const u=new SpeechSynthesisUtterance(String(t).replace(/[«»]/g,'')),p=VP[n]||[1,1];let ok=0;u.lang=v?v.lang.replace('_','-'):'ar-SA';if(v)u.voice=v;u.pitch=p[0];u.rate=p[1];u.volume=1;
  u.onstart=()=>ok=1;u.onerror=ev=>{if(!ok&&ev.error!='interrupted'&&ev.error!='canceled')blip(n,t)};window._u=u;
  const go=()=>{try{ss.resume();ss.speak(u)}catch(x){blip(n,t)}};if(ss.speaking||ss.pending){ss.cancel();setTimeout(go,120)}else go();
  VT=setTimeout(()=>{if(!ok){try{ss.cancel()}catch(x){}blip(n,t)}},2200)}catch(x){blip(n,t)}}
function bark(n,t){const b=$('#bk');b.innerHTML='<b>'+n+':</b> '+t;b.hidden=false;clearTimeout(bark.T);bark.T=setTimeout(()=>b.hidden=true,4200);speak(n,t)}
/* dialogue */
let DQ=null;
const busy=()=>!!DQ||!$('#dl').hidden;
function say(n,ls,ch,end){DQ={n,ls:[].concat(ls),i:0,ch,end};$('#dl').hidden=false;$('#dn').textContent=n;showL()}
function showL(){const d=DQ,c=$('#dc');$('#dt').textContent=d.ls[d.i];speak(d.n,d.ls[d.i]);document.body.classList.add('cin');c.innerHTML='';const last=d.i>=d.ls.length-1;
 if(last&&d.ch)d.ch.forEach(o=>c.append(btn(o.l,()=>{closeD();o.f&&o.f()})));else c.append(btn(last?'حسنًا':'التالي',()=>{if(last){closeD();d.end&&d.end()}else{d.i++;showL()}}))}
function closeD(){document.body.classList.remove('cin');clearTimeout(VT);try{speechSynthesis.cancel()}catch(e){}$('#dl').hidden=true;DQ=null}
function ask(n,h,test,ok,tx){DQ={};$('#dl').hidden=false;$('#dn').textContent=n;$('#dt').textContent=h;const c=$('#dc');c.innerHTML=tx?'<input id="pin" dir="auto" autocomplete="off" style="width:14ch;letter-spacing:0">':'<input id="pin" inputmode="numeric" maxlength="4" dir="ltr" autocomplete="off">';const i=$('#pin');
 const go=()=>{if(test(i.value)){closeD();sfx.door();ok()}else{sfx.bad();i.classList.remove('shk');void i.offsetWidth;i.classList.add('shk')}};c.append(btn('جرّب',go),btn('تراجع',closeD));i.onkeydown=e=>{e.stopPropagation();e.key=='Enter'&&go()};setTimeout(()=>i.focus(),50)}
/* story interactions */
function kamelTalk(){if(G.fl.kamel)return say(kamel.n,pick(BK[kamel.n]));
 say(kamel.n,['«انتحار. أو سرقة فاشلة. أغلق الملف يا تحرّي.»','«لكن… إن أصررت، فالبرج لك حتى الفجر.»'],[
 {l:'أصرّ على التحقيق',f:()=>{G.fl.kamel=1;rep('street',1);say(kamel.n,'«كما تشاء. الباب مفتوح لك.»')}},
 {l:'أعاونك على إغلاق القضية',f:()=>{G.fl.kamel=1;rep('police',1);rep('street',-1);addClue('watch');say(kamel.n,'«ذكي. خذ هذا: ساعة الميت، توقفت عند 3:47. ولا تسأل أكثر.»')}}])}
function nourTalk(){if(has('umbrella'))return say(nour.n,pick(BK[nour.n]));
 say(nour.n,'«الليل طويل. ماذا تريد؟»',[
 {l:'اسألها بلطف عن الدكتور',f:()=>G.rep.street>=1?(addClue('umbrella'),say(nour.n,'«خرج مع امرأة بمظلة بيضاء. لم تبدُ غريبة عنه.»')):say(nour.n,'«لا أعرفك. عد حين يعرفك الشارع.»')},
 {l:'هدّدها لتتكلم',f:()=>{rep('street',-2);addClue('umbrella');say(nour.n,'«امرأة بمظلة بيضاء! الآن اغرب عن وجهي!»')}},{l:'غادر'}])}
function zahirTalk(){if(G.fl.zok)return say(zahir.n,pick(BK[zahir.n]));
 say(zahir.n,'«تحرٍّ في مينائي؟ ثمن الفضول غالٍ.»',[{l:'صفقة: صمتي عنك مقابل الصناديق',f:()=>{G.fl.zok=1;rep('street',2);rep('police',-1);say(zahir.n,'«اتفقنا. افعل ما شئت، وبسرعة.»')}},{l:'ابتعد'}])}
function laylaTalk(){if(score()<3)return say(layla.n,pick(BK[layla.n]));
 say(layla.n,'«ما الذي تظن أنك تملك؟»',[{l:'واجهها بالأدلة',f:()=>fin('layla')},{l:'ليس بعد'}])}
function fin(s){if(G.done)return;G.done=1;try{localStorage.removeItem('sd3')}catch(e){}const sc=score();let t,x;
 if(s=='layla'){if(has('ledger')&&sc>=5){t='العدالة تتكلم';ach('justice');x='تضع الدفتر والشارة والمظلة أمامها فتنهار ليلى: اكتشف سمير أن مخزنها يخفي التهريب، فأسكتته وضبطت ساعته عند 3:47. عند الفجر تُقاد إلى السجن.'}
 else if(sc>=3){t='اعتراف ناقص';x='تعترف ليلى نصف اعتراف ثم تستدعي محاميها. القضية تنتهي بصفقة والحقيقة معلّقة.'}else{t='تفلت من الحبل';x='أدلتك لا تكفي. تغلق ليلى الباب في وجهك.'}}
 else if(s=='bribe'){t='الرجل الذي باع الحقيقة';x='تأخذ الظرف. تُغلق القضية انتحارًا وتتنفس ليلى فارس بحرية، وفي المرآة لا تعرف وجهك.'}else{t='اتهام خاطئ';x=(s=='zahir'?'أبو زاهر كان في الميناء طوال الليل':'المفتش كامل مغرور لكنه بريء')+'. القاتلة الحقيقية تراقب من نافذتها.'}
 if(s=='layla'&&has('bribe')&&has('ledger'))x+=' ويُقبض على المفتش كامل معها، والظرف دليل ضده.';const r=G.rep;x+=' '+(r.press>=3?'العناوين تحمل اسمك.':r.police>=3?'الشرطة تقف بجانبك.':r.street>=3?'الشارع يحميك.':r.police<=-3?'الشرطة لن تنسى ما فعلت.':'');
 const e=$('#end');e.hidden=false;e.innerHTML=`<h3>${t}</h3><p>${x}</p><p>الأدلة: ${sc}/8 · الرتبة: ${sc>=7?'محقق أسطوري':sc>=5?'محقق بارع':'محقق مبتدئ'}</p>`;e.append(btn('تحقيق جديد',()=>location.reload()))}
function dawn(){if(G.done)return;G.done=1;const e=$('#end');e.hidden=false;e.innerHTML='<h3>طلع الفجر</h3><p>انتهى الليل. من القاتل؟</p>';[['layla','ليلى فارس'],['zahir','أبو زاهر'],['kamel','المفتش كامل']].forEach(([k,n])=>e.append(btn(n,()=>{G.done=0;e.hidden=true;fin(k)})))}
/* interactables */
const I=[];const ia=(a,p,r,l,f,s)=>I.push({a,p,r,l,f,s});
const np=o=>()=>o.a?{x:o.x,z:o.z}:{x:o.g.position.x,z:o.g.position.z};
ia(0,np(kamel),3.2,()=>'تحدّث مع كامل',kamelTalk);ia(0,np(zahir),3.2,()=>'تحدّث مع أبي زاهر',zahirTalk);ia(0,np(layla),3.2,()=>'تحدّث مع ليلى',laylaTalk);ia(2,np(nour),3.5,()=>'تحدّث مع نور',nourTalk);
NP.filter(o=>o.t).forEach(o=>ia(0,np(o),2.6,()=>'تحدّث مع عابر',()=>say(o.n,o.lines[Math.random()*o.lines.length|0])));
const DR={1:{x:0,z:-56},2:{x:-32,z:9.5},3:{x:-64,z:-22.5}};
function enter(a){if(a==1&&!G.fl.kamel)return say('حارس',['«ممنوع الدخول. تحدّث مع المفتش كامل أولًا.»']);sfx.door();G.area=a;city.visible=false;INT[a].visible=true;pl.position.set(O[a][0],0,O[a][1]+1);cy=0}
function exit(a){sfx.door();INT[a].visible=false;city.visible=true;G.area=0;pl.position.set(DR[a].x,0,DR[a].z+2);cy=0;if(a==1&&has('ledger')&&!G.chase)startChase()}
ia(0,()=>DR[1],2.5,()=>'ادخل برج الساعة',()=>enter(1));ia(0,()=>DR[2],2.5,()=>'ادخل حانة الفانوس',()=>enter(2));
ia(1,()=>({x:O[1][0],z:O[1][1]+6}),2.5,()=>'اخرج',()=>exit(1));ia(2,()=>({x:O[2][0],z:O[2][1]+6}),2.5,()=>'اخرج',()=>exit(2));
ia(1,()=>({x:O[1][0]-3,z:O[1][1]-2}),2.8,()=>'افحص الجثة',()=>{if(has('watch'))say('أنت','تفحص الجثة مجددًا: لا شيء جديد. الساعة متوقفة عند 3:47.');else{addClue('watch');say('أنت','ساعة الدكتور محطّمة ومتوقفة عند 3:47. رقم يستحق التذكّر…')}});
ia(1,()=>({x:O[1][0]+4.5,z:O[1][1]-5.5}),2.8,()=>'افتح الخزنة',()=>{if(has('ledger'))return say('أنت','الخزنة فارغة الآن.');ask('الخزنة','قرص من أربع خانات. نُقش بجانبه: «الزمن الذي توقف هو المفتاح».',v=>v=='0347'||v=='347',()=>{addClue('ledger');say('أنت','دفتر حسابات سرّي… وتوقيع ليلى فارس على صفقات التهريب. وصوت خطوات خلف الباب!')})});
ia(0,()=>({x:70,z:70}),3.2,()=>'فتّش الصندوق',()=>{if(has('manifest'))return say('أنت','فارغ الآن.');if(!G.fl.zok)return say(zahir.n,'«ابتعد عن الصناديق!» يصرخ أبو زاهر من بعيد.');addClue('manifest');say('أنت','بيان الشحن: المخزن التاسع مسجّل باسم «فارس القابضة».')});
ia(0,()=>DR[3],2.5,()=>'ادخل أرشيف المدينة',()=>enter(3));ia(3,()=>({x:O[3][0],z:O[3][1]+6}),2.5,()=>'اخرج',()=>exit(3));
ia(3,np(idris),3.2,()=>'تحدّث مع إدريس',()=>say(idris.n,has('records')?pick(BK[idris.n]):['«سجلات الملّاك خلف هذا الرف، وقفلها لغز لا رمز.»','«الجواب شيء يعدّ الوقت ولا يشعر به.»']));
ia(3,()=>({x:O[3][0],z:O[3][1]-5.5}),3,()=>'افتح رف سجلات الملّاك',()=>{if(has('records'))return say('أنت','سجلات فارس بين يديك مسبقًا.');ask('رف السجلات','«أمشي بلا قدمين، وأدقّ بلا يد، ولي وجه لكني لا أرى. ما أنا؟»',v=>v.includes('ساع'),()=>{addClue('records');say('أنت','«فارس القابضة» يملكها فارس، وليلى وريثته ومديرته الفعلية. لا شك بعد الآن.')},1)});
ia(1,()=>({x:O[1][0]-4,z:O[1][1]-5.5}),2.8,()=>'فتّش المكتب',()=>{if(has('letter'))return say('أنت','المكتب فارغ الآن.');addClue('letter');say('أنت','رسالة نصف محترقة بخط سمير: «إن أصابني مكروه فالحقيقة في الخزنة… وليلى لا تعمل وحدها.» فمن شريكها؟')});
function kamelEv(){kamel.g.position.set(-58,0,78);kamel.x=-58;kamel.z=78;say(kamel.n,['«كنت أعلم أنك ستأتي إلى هنا.»','«ليلى تدفع أكثر مما تدفع الدولة. خذ هذا الظرف وانسَ الدفتر.»'],[{l:'خذ المال وأغلق القضية',f:()=>fin('bribe')},{l:'ارفض واحتفظ بالظرف دليلًا',f:()=>{addClue('bribe');ach('clean');rep('police',-2);rep('street',1);say(kamel.n,'«ستندم يا تحرّي… وستحتاج الشرطة يومًا.»')}}])}
const SS={fx:1,am:1,se:.006,lo:0};try{Object.assign(SS,JSON.parse(localStorage.getItem('sd3s')))}catch(e){}
function applyS(){FX=SS.fx;AM=SS.am;SENS=SS.se;try{localStorage.setItem('sd3s',JSON.stringify(SS))}catch(e){}RD.setPixelRatio(SS.lo?1:Math.min(devicePixelRatio,matchMedia('(pointer:coarse)').matches?1.5:2));SUN.castShadow=!SS.lo;rz()}
const AD={first:['أول خيط','اجمع دليلك الأول'],all:['محقق كامل','اجمع الأدلة الثمانية'],chase:['ما فلت مني','أمسك بالظلّ'],driver:['سائق الليل','اقطع مسافة طويلة بالسيارة'],clean:['يد نظيفة','ارفض رشوة كامل'],reader:['قارئ المذكرات','اجمع صفحات سمير الست'],late:['ليلة طويلة','اصمد حتى الخامسة فجرًا'],justice:['العدالة','أنهِ القضية بأفضل نهاية']};
let AO={};try{AO=JSON.parse(localStorage.getItem('sd3a'))||{}}catch(e){}
function ach(id){if(AO[id])return;AO[id]=1;try{localStorage.setItem('sd3a',JSON.stringify(AO))}catch(e){}toast('🏆 إنجاز: '+AD[id][0]);tone(880,.15,'triangle',.06);tone(1320,.3,'triangle',.06,.12)}
function pause(){if(!G.on||G.done||!$('#end').hidden)return;G.pause=!G.pause;try{speechSynthesis.cancel()}catch(e){}if(!G.pause){$('#pm').hidden=true;return}pm('m')}
function pm(v){const e=$('#pm');e.hidden=false;e.innerHTML='<div class="pb"><h3></h3><div id="po"></div></div>';const t=$('#pm h3'),o=$('#po'),B=(l,f)=>o.append(btn(l,f));
 if(v=='m'){t.textContent='متوقف مؤقتًا';B('متابعة',pause);B('الإعدادات',()=>pm('s'));B('الإنجازات',()=>pm('a'));B('التحكم والمساعدة',()=>pm('h'));B('بدء من جديد',()=>{try{localStorage.removeItem('sd3')}catch(x){}location.reload()})}
 else if(v=='s'){t.textContent='الإعدادات';[['fx','صوت المؤثرات',0,1,.05],['am','صوت الأجواء',0,1,.05],['se','حساسية الكاميرا',.002,.014,.001]].forEach(([k,l,a,b,st])=>{const r=document.createElement('label');r.textContent=l;const i=document.createElement('input');i.type='range';i.min=a;i.max=b;i.step=st;i.value=SS[k];i.oninput=()=>{SS[k]=+i.value;applyS()};r.append(i);o.append(r)});B('الجودة: '+(SS.lo?'منخفضة':'عالية'),()=>{SS.lo=SS.lo?0:1;applyS();pm('s')});B('رجوع',()=>pm('m'))}
 else if(v=='a'){t.textContent='الإنجازات';Object.keys(AD).forEach(k=>{const d=document.createElement('div');d.className='ch';d.textContent=(AO[k]?'🏆 ':'○ ')+AD[k][0];const sp=document.createElement('span');sp.textContent=AD[k][1];d.append(sp);o.append(d)});const pp=document.createElement('p');pp.textContent='صفحات المذكرات: '+G.pages+'/6';o.append(pp);B('رجوع',()=>pm('m'))}
 else{t.textContent='التحكم';o.innerHTML='<p>WASD حركة · Shift جري · Space قفز · E تفاعل · I الحقيبة · Esc إيقاف<br>السيارة: W/S بنزين وفرامل · A/D توجيه · Space يد · H بوق<br>اسحب لتدوير الكاميرا، واتبع السهم الأصفر للهدف، والتقط صفحات مذكرات سمير المتوهجة.</p>';B('رجوع',()=>pm('m'))}}
$('#pz').onclick=pause;
const LORE=['«الساعة لا تكذب… البشر وحدهم يفعلون. اكتشفت أن شركة فارس تهرّب عبر المخزن التاسع.»','«ليلى عرضت عليّ مالًا لأصمت. قلت لها إن الوقت لا يُشترى.»','«أبو زاهر لا يعرف ما في الصناديق. هو فقط يحرسها.»','«كامل يزور الفيلا كل خميس. ظننته صديقًا.»','«ضبطت الخزنة على الساعة التي أخشاها: ثلاثة وسبعة وأربعون.»','«إن قرأت هذا فأنا ميت. ابحث عن الشارة المطرّزة بحرف F.»'],PG=[];G.pages=0;
[[-48,-30],[48,30],[-16,-62],[16,60],[48,-60],[-48,62]].forEach(([x,z],i)=>{const g=new THREE.Group();g.add(new THREE.Mesh(new THREE.BoxGeometry(.5,.7,.03),new THREE.MeshBasicMaterial({color:0xf0e2b0})));const sp=new THREE.Sprite(GM);sp.scale.set(3,3,1);g.add(sp);g.position.set(x,1.2,z);city.add(g);const o={g,i,got:0};PG.push(o);ia(0,()=>({x,z}),2.6,()=>'التقط صفحة من مذكرات سمير',()=>{o.got=1;city.remove(g);G.pages++;sfx.clue();if(G.pages>=6)ach('reader');say('مذكرات سمير ('+G.pages+'/6)',LORE[i])},()=>!o.got)});
let CV=0,PSI=0,hitT=0,hitP=0,STE=0,hornT=0;const CT={l:0,r:0,g:0,b:0,h:0,hb:0};
function horn(){if(hornT>0)return;hornT=.5;tone(360,.4,'sawtooth',.06);tone(450,.4,'sawtooth',.05)}
for(const[id,k]of[['cl','l'],['cr','r'],['cg','g'],['cb','b'],['ch','h'],['cs','hb']]){const e=$('#'+id);e.onpointerdown=ev=>{CT[k]=1;try{e.setPointerCapture(ev.pointerId)}catch(x){}};e.onpointerup=e.onpointercancel=()=>CT[k]=0}
$('#cx').onpointerdown=toggleCar;
function toggleCar(){Object.keys(CT).forEach(k=>CT[k]=0);setTimeout(()=>document.body.classList.toggle('drv',!!G.drv));if(G.drv){G.drv=0;CV=0;pl.visible=true;const a=PSI+Math.PI/2;pl.position.set(PC.position.x+Math.cos(a)*2.4,0,PC.position.z-Math.sin(a)*2.4);$('#spd').hidden=true;if(ENG)ENG[1].gain.value=0;sfx.door()}else{G.drv=1;pl.visible=false;$('#spd').hidden=false;sfx.door();toast('W/S تسارع وفرامل · A/D توجيه · Space يد · H بوق · E نزول')}}
function drive(dt){hitT-=dt;hitP-=dt;hornT-=dt;G.km=(G.km||0)+Math.abs(CV)*dt;if(G.km>1500)ach('driver');const k=a=>K[a]?1:0;
 if(busy()||G.done)CV*=.95;else{const th=k('KeyW')+k('ArrowUp')-k('KeyS')-k('ArrowDown')-jz+CT.g-CT.b,st=k('KeyA')+k('ArrowLeft')-k('KeyD')-k('ArrowRight')-jx+CT.l-CT.r;if(K.Space||CT.hb)CV-=Math.sign(CV)*Math.min(Math.abs(CV),22*dt);if(K.KeyH||CT.h)horn();
  if(th>.1)CV+=th*(CV<0?30:14)*dt;else if(th<-.1)CV+=th*(CV>0?30:10)*dt;else CV-=Math.sign(CV)*Math.min(Math.abs(CV),6*dt);
  CV=clamp(CV,-8,24);STE+=(st-STE)*Math.min(1,dt*7);PSI+=STE*1.9*dt*clamp(CV/6,-1,1)}
 PC.position.x+=Math.cos(PSI)*CV*dt;PC.position.z-=Math.sin(PSI)*CV*dt;PC.rotation.y=PSI;{const U=PC.userData;U.fw.forEach(w=>w.rotation.y=STE*.45);U.wh.forEach(w=>w.rotation.z-=CV*dt/.38);U.tl.color.setHex((CT.b||K.KeyS||K.ArrowDown||K.Space||CT.hb||jz>.3)?0xff2a2a:0x771111);PC.rotation.x=-STE*.05*Math.min(1,Math.abs(CV)/15)}
 for(const b of BX){const cx=clamp(PC.position.x,b.x0,b.x1),cz=clamp(PC.position.z,b.z0,b.z1),dx=PC.position.x-cx,dz=PC.position.z-cz,d=Math.hypot(dx,dz);if(d<1.7){if(d>1e-4){PC.position.x+=dx/d*(1.7-d);PC.position.z+=dz/d*(1.7-d)}else PC.position.x+=1.7;if(Math.abs(CV)>5&&hitT<=0){sfx.bad();hitT=.5}CV*=.5}}
 PC.position.x=clamp(PC.position.x,-92,92);PC.position.z=clamp(PC.position.z,-92,92);
 pl.position.set(PC.position.x,0,PC.position.z);pl.rotation.y=Math.atan2(Math.cos(PSI),-Math.sin(PSI));
 if(Math.abs(CV)>8&&hitP<=0)for(const n of NP)if(n.t&&Math.hypot(n.x-PC.position.x,n.z-PC.position.z)<2.2){hitP=4;toast('صدمتَ أحد المارّة!');rep('police',-1);sfx.bad();break}
 if(ENG){ENG[0].frequency.value=45+Math.abs(CV)*4;ENG[1].gain.value=mute?0:Math.min(.05,.008+Math.abs(CV)*.003)}
 const ty=Math.atan2(-Math.cos(PSI),Math.sin(PSI));let d=ty-cy;d=Math.atan2(Math.sin(d),Math.cos(d));cy+=d*Math.min(1,dt*3);
 RUNF=Math.abs(CV)>12?1:0;$('#spd').textContent=Math.round(Math.abs(CV)*3.6)+' كم/س'}
ia(0,()=>({x:PC.position.x,z:PC.position.z}),4.2,()=>G.drv?'انزل من السيارة':'اركب السيارة',toggleCar);I[I.length-1].car=1;
/* objective */
function obj(){if(!G.fl.kamel)return['تحدّث مع المفتش كامل عند برج الساعة',kamel.g.position];if(!has('ledger'))return['ادخل برج الساعة وابحث عن الأدلة',DR[1]];if(G.chase&&!G.chase.done)return['طارد الظلّ! اركض بـ Shift',G.chase.g.position];
 if(!has('umbrella'))return['اسأل نور في حانة الفانوس',DR[2]];if(!has('manifest'))return['فتّش صناديق الرصيف شرقًا',{x:70,z:70}];if(!has('records'))return['ابحث في أرشيف المدينة غربًا',DR[3]];return['واجه ليلى فارس عند الفيلا',layla.g.position]}
const bc=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,60,12,1,true),new THREE.MeshBasicMaterial({color:0xe3a950,transparent:true,opacity:.25,side:THREE.DoubleSide,depthWrite:false,fog:false}));bc.position.y=30;SC.add(bc);
/* input */
const K={};let cy=0,jx=0,jz=0,jump=0,runT=0;
addEventListener('keydown',e=>{if(e.target.tagName=='INPUT')return;K[e.code]=1;if(e.code=='KeyE'||e.code=='Enter')act();if(e.code=='Space')e.preventDefault();if(e.code=='KeyI')bag();if(e.code=='Escape'||e.code=='KeyP')pause()});
addEventListener('keyup',e=>K[e.code]=0);
let dg=null;const cvs=RD.domElement;
cvs.onpointerdown=e=>{dg={id:e.pointerId,x:e.clientX};cvs.setPointerCapture(e.pointerId)};cvs.onpointermove=e=>{if(dg&&e.pointerId==dg.id){cy-=(e.clientX-dg.x)*SENS;dg.x=e.clientX}};cvs.onpointerup=cvs.onpointercancel=()=>dg=null;
const js=$('#js'),kn=$('#kn');let jid=null;
function jm(e){const r=js.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.min(1,Math.hypot(dx,dy)/(r.width/2)),a=Math.atan2(dy,dx);jx=Math.cos(a)*m;jz=Math.sin(a)*m;kn.style.transform=`translate(${jx*35}px,${jz*35}px)`}
js.onpointerdown=e=>{jid=e.pointerId;js.setPointerCapture(jid);jm(e)};js.onpointermove=e=>e.pointerId==jid&&jm(e);js.onpointerup=js.onpointercancel=()=>{jid=null;jx=jz=0;kn.style.transform=''};
$('#bj').onpointerdown=()=>jump=1;$('#br').onpointerdown=()=>{runT=!runT;$('#br').style.borderColor=runT?'var(--lamp)':''};$('#ba').onpointerdown=act;
$('#bag').onclick=bag;$('#vo').onclick=()=>{VO=!VO;$('#vo').style.opacity=VO?1:.4;if(!VO)try{speechSynthesis.cancel()}catch(e){}else speak('أنت','مرحبًا، أنا المحقق. هل تسمعني؟')};$('#snd').onclick=()=>{mute=!mute;$('#snd').textContent=mute?'🔇':'🔊';if(amb){amb.gain.value=mute?0:.018}};
function bag(){const v=$('#inv');v.hidden=!v.hidden;if(v.hidden)return;v.innerHTML='<h4>الحقيبة</h4>'+(G.clues.length?G.clues.map(c=>`<b class="ch">${CN[c][0]}<span>${CN[c][1]}</span></b>`).join(''):'<p style="color:var(--mut)">فارغة. استكشف المدينة.</p>')+'<h4>السمعة</h4><p>'+Object.keys(RP).map(k=>RP[k]+': '+(G.rep[k]>=3?'حليف':G.rep[k]<=-3?'عدو':'محايد')).join(' · ')+'</p>'}
let cur=null;
function act(){if(!G.on)return;if(DQ){const b=$('#dc button');if(b&&$('#dc').children.length==1)b.click();return}if(cur){sfx.click();cur.f()}}
$('#pr').onclick=act;
/* update */
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const mmL=document.createElement('canvas');mmL.width=mmL.height=110;
function buildMM(){const g=mmL.getContext('2d');g.fillStyle='#0d1319';g.fillRect(0,0,110,110);g.fillStyle='#2b3744';BX.forEach(b=>g.fillRect((b.x0+100)*.55,(b.z0+100)*.55,(b.x1-b.x0)*.55,(b.z1-b.z0)*.55))}
const mm=$('#mm').getContext('2d');let lastOb='',lastPr='',stepT=0,vy=0,pa=0,orb=0;
function env(dt){if(G.on&&!G.done&&!G.pause)G.t+=dt/90;const h=G.t%24,dl=Math.max(0,Math.sin((h-6)/12*Math.PI)),dw=Math.max(0,1-Math.abs(h-6)/1.5);
 const c=new THREE.Color(0x04070b).lerp(new THREE.Color(0x5f7f9f),dl).lerp(new THREE.Color(0xc98a5a),dw*.7);SC.background=c;SC.fog.color=c;
 G.nl-=dt;if(G.nl<=0){G.lf=1;G.nl=35+Math.random()*40;setTimeout(thunder,500)}G.lf=Math.max(0,G.lf-dt*3);
 const ins=G.area?1:0;HEM.intensity=(ins?.8:.3+dl*.7)+G.lf*2.5;SUN.intensity=ins?0:.25+dl*1.1;EM.forEach(m=>m.emissiveIntensity=1-dl*.85);GM.opacity=.1+(1-dl)*.7;LP.opacity=.04+(1-dl)*.45;if(G.on&&G.t>=29)ach('late');if(ambR)ambR.gain.value=mute?0:(G.area?.002:.008)*AM;if(amb)amb.gain.value=mute?0:.018*AM;{const nt=G.area?0:Math.max(0,1-dl*1.6);STM.opacity=nt;MN.material.opacity=nt*.9;STR.visible=MN.visible=!G.area;STR.position.copy(CAM.position);MN.position.set(CAM.position.x-120,CAM.position.y+110,CAM.position.z-160)}LAMP.intensity=ins?.6:.6+(1-dl)*1.2;
 $('#clk').textContent=String(h|0).padStart(2,'0')+':'+String((h%1)*60|0).padStart(2,'0');if(G.t>=30&&G.on&&!G.done)dawn()}
function update(dt){RUNF=0;
 if(G.drv){drive(dt)}else if(!busy()&&!G.done){const k=(a,b)=>(K[a]||K[b]?1:0);let ix=k('KeyD','')-k('KeyA','')+jx,iz=k('KeyS','')-k('KeyW','')+jz;k('ArrowRight','')&&0;
  cy+=(k('ArrowLeft','')-k('ArrowRight',''))*dt*2;k('ArrowUp','');
  const l=Math.hypot(ix,iz);if(l>1){ix/=l;iz/=l}const rq=K.ShiftLeft||K.ShiftRight||runT,run=rq&&l>.1&&!stx;RUNF=run;stm=clamp(stm+(run?-10:16)*dt,0,100);if(stm<=0)stx=1;if(stm>=35)stx=0;$('#sb i').style.width=stm+'%';const sp=run?8.5:4.5,mx=Math.cos(cy)*ix+Math.sin(cy)*iz,mz=-Math.sin(cy)*ix+Math.cos(cy)*iz;
  pl.position.x+=mx*sp*dt;pl.position.z+=mz*sp*dt;
  if(l>.1){const ta=Math.atan2(mx,mz);let d=ta-pl.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));pl.rotation.y+=d*Math.min(1,dt*12);pa+=dt*(run?14:9);anim(pl,pa);{const b=pl.userData.bd;b.rotation.x+=((run?.22:0)-b.rotation.x)*Math.min(1,dt*10)}stepT-=dt;if(stepT<=0&&pl.position.y<.05){sfx.step();stepT=run?.26:.4}}else anim(pl,0,0);
  if((K.Space||jump)&&pl.position.y<=0){vy=7.5}jump=0}
 vy-=20*dt;pl.position.y=Math.max(0,pl.position.y+vy*dt);if(pl.position.y==0)vy=0;
 if(G.area){const o=O[G.area];pl.position.x=clamp(pl.position.x,o[0]-6.3,o[0]+6.3);pl.position.z=clamp(pl.position.z,o[1]-6.3,o[1]+5.8)}
 else{for(const b of BX){const cx=clamp(pl.position.x,b.x0,b.x1),cz=clamp(pl.position.z,b.z0,b.z1),dx=pl.position.x-cx,dz=pl.position.z-cz,d=Math.hypot(dx,dz);if(d<.55){if(d>1e-4){pl.position.x+=dx/d*(.55-d);pl.position.z+=dz/d*(.55-d)}else pl.position.x+=.55}}pl.position.x=clamp(pl.position.x,-92,92);pl.position.z=clamp(pl.position.z,-92,92)}
 for(const n of NP)if(n.t&&!G.area){const dx=n.tx-n.x,dz=n.tz-n.z,d=Math.hypot(dx,dz);if(d<.3){const o=[[1,0],[-1,0],[0,1],[0,-1]][Math.random()*4|0],a=n.ix+o[0],b=n.iz+o[1];if(a>=0&&a<4&&b>=0&&b<4){n.ix=a;n.iz=b;n.tx=ST[a]+n.off;n.tz=ST[b]+n.off}}else{n.x+=dx/d*2*dt;n.z+=dz/d*2*dt;n.g.position.set(n.x,0,n.z);n.g.rotation.y=Math.atan2(dx,dz);anim(n.g,G.t*400)}}
 for(const n of NP)if(!n.t&&n.a==G.area){const dx=pl.position.x-n.x,dz=pl.position.z-n.z;if(dx*dx+dz*dz<64){let d=Math.atan2(dx,dz)-n.g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));n.g.rotation.y+=d*Math.min(1,dt*6);const pu=n.g.userData.pu;if(pu)pu.forEach((q,k)=>q.position.x=(k?.038:-.038)+Math.sin(d)*.008)}}
 for(const c of CR){c.g.userData.wh.forEach(w=>w.rotation.z-=c.v*dt/.38);c.p+=c.s*c.v*dt;if(c.p>95)c.p=-95;if(c.p<-95)c.p=95;c.g.position.set(c.ax?c.l:c.p,0,c.ax?c.p:c.l);c.g.rotation.y=c.ax?(c.s>0?-Math.PI/2:Math.PI/2):(c.s>0?0:Math.PI);if(!G.area){const dx=pl.position.x-c.g.position.x,dz=pl.position.z-c.g.position.z;if(Math.hypot(dx,dz)<2.4){pl.position.x+=dx*.25;pl.position.z+=dz*.25}}}
 if(!G.area&&!G.fl.kev&&score()>=4&&!busy()&&!G.done&&Math.hypot(pl.position.x+64,pl.position.z-72)<26){G.fl.kev=1;chapter('الفصل الرابع','ما تحت المصباح');setTimeout(kamelEv,2800)}
 {const tm=performance.now()/4000;for(const v of SV2){const p=(tm+v.o)%1;v.sq.position.set(v.x,.5+p*5,v.z);v.sq.scale.set(2+p*5,2+p*5,1);v.sq.material.opacity=.28*(1-p)*Math.min(1,p*6)}}
 bkT-=dt;if(bkT<=0&&!busy()&&!G.done){bkT=8+Math.random()*7;const cs=NP.filter(n=>n.a==G.area&&Math.hypot(n.x-pl.position.x,n.z-pl.position.z)<9);if(cs.length){const n=pick(cs),ls=n.t?LN:BK[n.n];if(ls)bark(n.n,pick(ls))}}
 {const tn=performance.now()/400;for(const o of PG)if(!o.got){o.g.rotation.y+=dt*2;o.g.position.y=1.2+Math.sin(tn+o.i)*.15}}
 chaseUpd(dt);gear.rotation.z+=dt*.5;
 const D=G.area?5:G.drv?10:7.5,H=G.area?2.8:G.drv?4.8:4.2;let tx=pl.position.x+Math.sin(cy)*D,tz=pl.position.z+Math.cos(cy)*D,ty=pl.position.y+H;
 if(G.area){const o=O[G.area];tx=clamp(tx,o[0]-6.4,o[0]+6.4);tz=clamp(tz,o[1]-6.4,o[1]+6.4);ty=Math.min(ty,4.3)}
 if(!G.area){const px=pl.position.x,pz=pl.position.z,fr=(x,z)=>!BX.some(b=>x>b.x0-.6&&x<b.x1+.6&&z>b.z0-.6&&z<b.z1+.6);let f=1;while(f>.25&&![.3,.6,1].every(q=>fr(px+(tx-px)*f*q,pz+(tz-pz)*f*q)))f-=.1;tx=px+(tx-px)*f;tz=pz+(tz-pz)*f}
 if(!G.area&&!G.done&&(sv-=dt)<0){sv=5;SV()}
 CAM.fov+=((RUNF?70:62)-CAM.fov)*Math.min(1,dt*6);CAM.updateProjectionMatrix();CAM.position.lerp(new THREE.Vector3(tx,ty,tz),1-Math.pow(.002,dt));CAM.lookAt(pl.position.x,pl.position.y+1.5,pl.position.z);
 SUN.position.set(pl.position.x+20,35,pl.position.z+12);SUN.target.position.copy(pl.position);LAMP.position.set(pl.position.x,3,pl.position.z);
 cur=null;let bd=99;if(!busy())for(const i of I){if(i.a!=G.area||(i.s&&!i.s())||(G.drv&&!i.car))continue;const p=i.p(),d=Math.hypot(p.x-pl.position.x,p.z-pl.position.z);if(d<i.r&&d<bd){bd=d;cur=i}}
 const pt=cur?'E · '+cur.l():'';if(pt!=lastPr){lastPr=pt;$('#pr').hidden=!pt;$('#pr').textContent=pt}
 const o=obj();objT+=dt;if(objT>100){objT=-9999;toast('تلميح: اتبع عمود الضوء الأصفر')}
 if(o[0]!=lastOb){if(lastOb){toast('هدف جديد');tone(740,.2,'triangle',.05);objT=0}lastOb=o[0];$('#ob').textContent=o[0]}
 {const a=$('#ar');if(G.area||G.done)a.hidden=true;else{a.hidden=false;const dx=o[1].x-pl.position.x,dz=o[1].z-pl.position.z,xr=dx*Math.cos(cy)-dz*Math.sin(cy),xf=-dx*Math.sin(cy)-dz*Math.cos(cy);$('#ai').style.transform='rotate('+Math.atan2(xr,xf)+'rad)';$('#ad').textContent=Math.round(Math.hypot(dx,dz))+' م'}}
 bc.visible=!G.area;bc.position.x=o[1].x;bc.position.z=o[1].z;bc.material.opacity=.18+Math.sin(G.t*500)*.08;
 mm.drawImage(mmL,0,0);if(!G.area){NP.forEach(n=>{if(n.a)return;const p=n.g.position;mm.fillStyle=n.t?'#6c7886':'#7fb3bd';mm.fillRect((p.x+100)*.55-1.5,(p.z+100)*.55-1.5,3,3)});
  mm.strokeStyle='#e3a950';mm.beginPath();mm.arc((o[1].x+100)*.55,(o[1].z+100)*.55,4+Math.sin(G.t*600)*1.5,0,7);mm.stroke();
  PG.forEach(o=>{if(!o.got){mm.fillStyle='#f0e2b0';mm.fillRect((o.g.position.x+100)*.55-1.5,(o.g.position.z+100)*.55-1.5,3,3)}});mm.fillStyle='#b8484b';mm.fillRect((PC.position.x+100)*.55-2.5,(PC.position.z+100)*.55-2.5,5,5);mm.save();mm.translate((pl.position.x+100)*.55,(pl.position.z+100)*.55);mm.rotate(-pl.rotation.y+Math.PI);mm.fillStyle='#e3a950';mm.beginPath();mm.moveTo(0,-5);mm.lineTo(3.5,4);mm.lineTo(-3.5,4);mm.fill();mm.restore()}
 else{mm.fillStyle='#e3a950';mm.font='12px Tajawal';mm.textAlign='center';mm.fillText('داخل مبنى',55,58)}}
let last=0,sv=5,stm=100,stx=0,RUNF=0,objT=0,bkT=5;const SV=()=>{try{localStorage.setItem('sd3',JSON.stringify({t:G.t,c:G.clues,r:G.rep,f:G.fl,x:pl.position.x,z:pl.position.z,pg:PG.map(o=>o.got?1:0)}))}catch(e){}};
function loop(ts){requestAnimationFrame(loop);const dt=Math.min(.05,(ts-last)/1000||0);last=ts;env(dt);
 if(G.on){if(!G.pause)update(dt)}else{orb+=dt*.1;CAM.position.set(Math.sin(orb)*70,30,Math.cos(orb)*70);CAM.lookAt(0,6,0);SUN.position.set(20,35,12)}RD.render(SC,CAM)}
buildMM();SC.background=new THREE.Color(0x04070b);requestAnimationFrame(loop);
function chapter(a,b){const c=$('#chp');c.innerHTML=`<small>${a}</small><h2>${b}</h2>`;c.classList.remove('on');void c.offsetWidth;c.classList.add('on');tone(110,1.2,'sine',.05,0,70)}
function cine(ls,cb){const e=$('#cn');e.hidden=false;let i=0,d=0;const nx=()=>{if(d)return;if(i>=ls.length){d=1;e.hidden=true;cb();return}e.innerHTML='<p>'+ls[i++]+'</p>';setTimeout(nx,3200)};e.onclick=()=>{if(!d){d=1;e.hidden=true;cb()}};nx()}
function begin(){applyS();chapter('الفصل الأول','ساعة متوقفة');try{speechSynthesis.getVoices();const u1=new SpeechSynthesisUtterance(' ');u1.volume=0;speechSynthesis.speak(u1)}catch(e){}$('#intro').hidden=true;$('#hud').hidden=false;G.on=1;ac()&&ac().resume();startAmb();toast('اقترب من الشخصيات والأبواب ثم اضغط E')}
$('#go').onclick=()=>{try{localStorage.removeItem('sd3')}catch(e){}ac()&&ac().resume();try{const u0=new SpeechSynthesisUtterance(' ');u0.volume=0;speechSynthesis.speak(u0)}catch(e){}cine(['مدينة لا تنام… لأن أحدًا فيها لا يجرؤ على إغماض عينيه.','سمير حداد، صانع الساعات، وُجد ميتًا تحت ساعة برجه… والساعة متوقفة.','أنت آخر محقق لم يشترِه أحد. أمامك حتى الفجر.'],begin)};
try{const v=JSON.parse(localStorage.getItem('sd3'));if(v&&v.c){$('#cont').hidden=false;$('#cont').onclick=()=>{G.t=v.t;G.clues=v.c;G.rep=v.r;G.fl=v.f;pl.position.set(v.x,0,v.z);if(has('ledger'))G.chase={done:1};(v.pg||[]).forEach((q,i)=>{if(q){PG[i].got=1;city.remove(PG[i].g);G.pages++}});begin()}}}catch(e){}
